/*
** client.c -- a stream socket client demo
*/

#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <errno.h>
#include <string.h>
#include <string>
#include <cstring>
#include <netdb.h>
#include <sys/types.h>
#include <netinet/in.h>
#include <sys/socket.h>
#include <arpa/inet.h>
#include <pthread.h>
#include <sys/time.h>
#include <time.h>
#include <ctime>
#include "struct1.h"
#include <iostream>       // std::cin, std::cout
#include <queue>          // std::queue
#include <map>            //std::map c++11
#include "spliter.h"
#include "key_store.h"

#define TICK_USEC      100000 // tick length in microseconds currently 0.1s          

using namespace std;

void *delay_thread(void *x_void_ptr);
void *receive_thread(void *x_void_ptr);
void pause(int dur);
//send helper with different parameters
void reg_send(char *msg);
void reg_send_string(string msg);

#define PORT "3490" // the port client will be connecting to 
#define MAXDATASIZE 200 // max number of bytes we can get at once 

//global variables
queue<Message> myqueue;
char terminal;
int sockfd;
pthread_t receive_t;
pthread_t delay_t[100];
volatile bool ack_flag=false; //waiting for an ack coming from central
pthread_mutex_t ack_mutex = PTHREAD_MUTEX_INITIALIZER;

//local key-value store global viewable
key_store mystore;

/* 
 * time_is_after 
 *   DESCRIPTION: Check whether one time is at or after a second time.
 *   INPUTS: t1 -- the first time
 *           t2 -- the second time
 *   OUTPUTS: none
 *   RETURN VALUE: 1 if t1 >= t2
 *                 0 if t1 < t2
 *   SIDE EFFECTS: none
 */
//delay thread
void *delay_thread(void *dummyPtr)
{
    //temp storage for received message parsing
    char dest_name[2];
    string control;
    int key;
    int value;
    int model;
    long timestamp;
    int read_ret;
    string src;
    char recv_msg[MAXDATASIZE];


cout<<"debug1"<<endl;
    float terminal_time;
    srand(time(NULL));
    switch(terminal){
      //type in the terminal number
      case 'a': terminal_time=rand()%200; break;
      case 'b': terminal_time=rand()%400; break;
      case 'c': terminal_time=rand()%150; break;
      case 'd': terminal_time=rand()%1000; break;

    }
      cout<<terminal_time<<endl;
      usleep(terminal_time/10*TICK_USEC);  //delay
    cout<<"I wake up!"<<" my number is: "<<pthread_self()<<endl;
    while (!myqueue.empty())
      {
          cout<<pthread_self()<<" waiting to be top!"<<" top number is: "<<*myqueue.front().myID<<endl;
          while(*(myqueue.front().myID)!=pthread_self()); //if the delay thread is not in the front
            /*  //test "A send hello B"
            sscanf(myqueue.front().buf,"%s send %s ", dest_name, recv_msg);
            splitstring recv_msg_test(myqueue.front().buf);
            vector<string> chunk = recv_msg_test.split(' ');
            cout<<"chunk has size "<<chunk.size()<<endl;
            cout<<"Received: "<<recv_msg<<" from "<<dest_name<<endl;
            */
            //parsing delivered message 
            splitstring recv_msg(myqueue.front().buf);
            vector<string> chunk = recv_msg.split(' ');
            control = chunk[0];
            // c_control is char* version of control word
            char *c_control = new char[control.length()+1];
            strcpy(c_control, control.c_str());

            //check whether is recving ACK from central            
            if(strcmp(c_control,"ACK") == 0){
                cout<<"received central ACK!"<<endl;
                if(chunk.size()==3){
                  int get_key = stoi(chunk[1]);
                  int get_value = stoi(chunk[2]);
                  cout<<"get_key received: "<<get_key<<' '<<get_value<<endl;
                }
                pthread_mutex_lock (&ack_mutex);
                ack_flag = true;
                pthread_mutex_unlock (&ack_mutex);
                delete [] c_control;
                if(!myqueue.empty())
                myqueue.pop();
                break;
            }
            else{ 
            //second, chunk[1] is key 
            key = stoi(chunk[1],NULL,0);

            //delete, insert and update only takes local changes and send an ACK back
            if(strcmp(c_control,"delete")==0){
                mystore.delete_key(key);
            } else if(strcmp(c_control,"insert")==0){
                model = stoi(chunk[3],NULL,0);
                value = stoi(chunk[2], NULL, 0);
                mystore.insert_key(key, value);    //chunk[2] should be the value for insert and update
            } else if(strcmp(c_control,"update")==0){
                model = stoi(chunk[3],NULL,0);
                value = stoi(chunk[2], NULL, 0);
                mystore.update_key(key, value);
            //get needs to send back time stamp and read value
            //get key model    
            } else if(strcmp(c_control,"get")==0){
                model = stoi(chunk[2],NULL,0);
                if(model==1) goto label1;
                if(model==3 || model==4){
                cout<<"enter here!"<<endl;
                read_ret = mystore.get_key(key);
                string key_str = to_string(static_cast<long long>(key));
                string read_ret_str = to_string(static_cast<long long>(read_ret));
                time_t now = time(0);
                string now_str = to_string(static_cast<long long>(now));
                string get_msg = "ACK "+ key_str +' '+ read_ret_str + ' ' + now_str+' '+chunk[2];//+ model
                cout <<"get_msg is: "<<get_msg<<endl;
                reg_send_string(get_msg);
                }
                delete [] c_control;
                if(!myqueue.empty())
                myqueue.pop();
                break;
            } else {
              cout <<"cannot recognize control word!"<<endl;
              delete [] c_control;
              if(!myqueue.empty())
              myqueue.pop();
              break;
            }
    label1:      
            delete[] c_control; //all done with c_control
            string ack("ACK");
            reg_send_string(ack); 

            /*
            if(chunk.size() == 3) //delete key src
               src = chunk[2];
            else if(chunk.size() == 4){ //get key model 
               model =
            }
            else{
              value = stoi(chunk[2],NULL,0);
              model = stoi(chunk[3],NULL,0); 
            }
            if()
            //cout<<"Received ";
            //for (int k = 0; k < chunk.size(); k++){
            //    cout<<' '<<chunk[k];
            //}*/
            time_t now = time(0);
            char* cur_time = ctime(&now);
            if(chunk.size() == 2)
            cout<<"Received: "<<control<<" "<<key<<endl;//print out the message
            else if (chunk.size() == 3)
            cout<<"Received: "<<control<<" "<<key<<endl;//print out the message
            else
            cout<<"Received: "<<control<<" "<<key<<" "<<value<<" "<<model<<endl;
            
            }
            if(!myqueue.empty())
            myqueue.pop();
            break;
      } 
cout<<"debug2"<<endl;  
}

//receive thread
void *receive_thread(void *x_void_ptr)
{
  Message message_struct;
  int counter=0;
  int numbytes=0;
  while(1)
  {
    if ((numbytes = recv(sockfd, message_struct.buf, MAXDATASIZE-1, 0)) > 0) 
    {//once receive a message, continue
      if(numbytes == -1)//receive fails
      {
          perror("recv");
          //exit(1);
      }
      else
      {   
          message_struct.counter=counter;
          //store delay thread ID into my stack
          message_struct.myID = &delay_t[message_struct.counter];
          counter++;
          myqueue.push (message_struct);
          memset(message_struct.buf,'\0',sizeof message_struct.buf);
          //problem: every source should have a seperate queue for them, so should be 4 queues, this code is buggy
          if(pthread_create(&(delay_t[message_struct.counter]), NULL, delay_thread, NULL)) 
          {
              fprintf(stderr, "Error creating thread\n");          
          }

      }
    }     
  }  
  
}

void reg_send(char *msg){
    if(send(sockfd,msg,(strlen(msg)),0)==-1)
          perror("send");//send message
      time_t now = time(0);
      char* cur_time = ctime(&now);
      cout<<"sending... ("<<msg<<" )current sys time is"<<cur_time<<endl;
      usleep(5*TICK_USEC);
}

//regular send string version for keyborad input
void reg_send_string(string msg){
    char *mymsg = new char [msg.length()+1];
    strcpy(mymsg, msg.c_str());
    if(send(sockfd,mymsg,msg.length(),0)==-1)
          perror("send");//send message
    delete [] mymsg;
      time_t now = time(0);
      char* cur_time = ctime(&now);
      cout<<"sending... ("<<msg<<") current sys time is"<<cur_time<<endl;
      usleep(5*TICK_USEC);
}

// get sockaddr, IPv4 or IPv6:
void *get_in_addr(struct sockaddr *sa)
{
    if (sa->sa_family == AF_INET) {
        return &(((struct sockaddr_in*)sa)->sin_addr);
    }

    return &(((struct sockaddr_in6*)sa)->sin6_addr);
}

int main(int argc, char *argv[])
{
    //int sockfd, numbytes;  
    int numbytes; 
    char buf[MAXDATASIZE];
    struct addrinfo hints, *servinfo, *p;
    int rv;
    char s[INET6_ADDRSTRLEN];

    int choice;//choose input mode
    bool flag = true;

    FILE *fp;// do preparation work for reading file
    char ch='\0';
    int numbytes1=0;
    char msg[100];
    string mymsg;

    if (argc != 2) {
        fprintf(stderr,"usage: client hostname\n");
        exit(1);
    }

    memset(&hints, 0, sizeof hints);
    hints.ai_family = AF_UNSPEC;
    hints.ai_socktype = SOCK_STREAM;

    if ((rv = getaddrinfo(argv[1], PORT, &hints, &servinfo)) != 0) {
        fprintf(stderr, "getaddrinfo: %s\n", gai_strerror(rv));
        return 1;
    }

    // loop through all the results and connect to the first we can
    for(p = servinfo; p != NULL; p = p->ai_next) {
        if ((sockfd = socket(p->ai_family, p->ai_socktype,
                p->ai_protocol)) == -1) {
            perror("client: socket");
            continue;
        }

        if (connect(sockfd, p->ai_addr, p->ai_addrlen) == -1) {
            close(sockfd);
            perror("client: connect");
            continue;
        }

        break;
    }

    if (p == NULL) {
        fprintf(stderr, "client: failed to connect\n");
        return 2;
    }

    inet_ntop(p->ai_family, get_in_addr((struct sockaddr *)p->ai_addr),
            s, sizeof s);
    printf("client: connecting to %s\n", s);

    freeaddrinfo(servinfo); // all done with this structure

  int x = 0;
  cout<<"please enter terminal number"<<endl;
  cin>>terminal;//read in the terminal name
  cin.ignore(); //ignore delimiter newline character
  // create a receive thread
  if(pthread_create(&receive_t, NULL, receive_thread,(void*) &x)) {

    fprintf(stderr, "Error creating thread\n");
    return 1;
  }

loop:
  while(1){
  do{
  cout <<"please select input mode: keyboard(1), input file(2)"<<endl;
  scanf("%d",&choice);
  cin.ignore();
  cout<<choice<<endl;
  cout<<flag<<endl;
  if(choice ==2) flag=false;
  else if(choice == 1){
        cout<<"please input message to send: ";
        flag = true;
        getline(cin, mymsg);
        cout<<"mymsg is "<<mymsg<<endl;

        char *c_mymsg_str = new char[mymsg.length()+1];
        strcpy(c_mymsg_str, mymsg.c_str());
        
        splitstring search_msg(c_mymsg_str);
        vector<string> search_chunk = search_msg.split(' ');
        char *c_mymsg_str_2 = new char[search_chunk[0].length()+1];
        strcpy(c_mymsg_str_2, search_chunk[0].c_str());

        if(strcmp(c_mymsg_str_2, "showall") == 0)
        {
            mystore.showall();
            delete [] c_mymsg_str;
            delete [] c_mymsg_str_2;
            continue;
        }

        if(strcmp(c_mymsg_str_2, "search") == 0)
        {
            int temp_key;
            temp_key = stoi(search_chunk[1]);
            mystore.search(temp_key);
            delete [] c_mymsg_str;
            delete [] c_mymsg_str_2;
            continue;
        }

        //print local value for get model 2 and send nothing
        if(strcmp(c_mymsg_str_2, "get") ==0){
          int temp_model = stoi(search_chunk[2]);
          if(temp_model==2){
          int temp_key=stoi(search_chunk[1]);
          cout<<"get model 2 with key: "<<temp_key<<", value is: "<<mystore.get_key(temp_key)<<endl;
          delete [] c_mymsg_str;
          delete [] c_mymsg_str_2;
          continue;
          }
        }

        //delete local variable directly but do not wait for central ACK
        if(strcmp(c_mymsg_str_2, "delete") ==0){
          int temp_key=stoi(search_chunk[1]);
          mystore.delete_key(temp_key);
          reg_send_string(mymsg);
          goto label2;
        }
        

        reg_send_string(mymsg);
        //waiting an ACK before next input
        cout<<"I am waiting central ACK!"<<endl;
        pthread_mutex_lock (&ack_mutex);
        ack_flag = false;
        pthread_mutex_unlock (&ack_mutex);
        while(!ack_flag);
        //print local value for get model 1 after receving 4 ACK from central
        if(strcmp(c_mymsg_str_2, "get") ==0){
          int temp_model = stoi(search_chunk[2]);
          if(temp_model==1){
          int temp_key=stoi(search_chunk[1]);
          cout<<"get model 1 with key: "<<temp_key<<", value is: "<<mystore.get_key(temp_key)<<endl;
          }
        }
    label2:
        delete [] c_mymsg_str;
        delete [] c_mymsg_str_2;
        goto loop;
    }
    else {
    cout<< "invalid choice! pick an input mode!"<<endl;
    flag = true;
    } 
  } while(flag);

  //parsing input file
  switch (terminal){
    case 'a':
    fp=fopen("input_1.txt","r"); break;
    case 'b':
    fp=fopen("input_2.txt","r"); break;
    case 'c':
    fp=fopen("input_3.txt","r"); break;
    case 'd':
    fp=fopen("input_4.txt","r"); break;
    default:
    cout<<"invalid terminal number!"<<endl; continue;
  }
  cout<<"reach here!"<<endl;
    fseek(fp,0, SEEK_SET);
    cout<<"debug3"<<endl;

    while(ch!=EOF){
      memset(msg,'\0', sizeof(msg));
      do{   
          ch=fgetc(fp);
          if(ch!='\n' && ch !=EOF){
          msg[numbytes1]=ch;
          numbytes1++;
          }
        }while (ch!='\n' && ch!=EOF && ch!='\r');
        //testing
        //cout<<"numbytes1: "<<numbytes1<<endl;
        //cout<< msg<<endl;
        //cout<<"strlen is: "<<strlen(msg)<<endl;
        //while(numbytes<1000){numbytes++;}
        splitstring control_msg(msg);
        vector<string> control_chunk = control_msg.split(' ');
        char *c_control_str = new char[control_chunk[0].length()+1];
        strcpy(c_control_str, control_chunk[0].c_str());

        if(strcmp(c_control_str, "showall") == 0)
        {
            mystore.showall();
            delete [] c_control_str;
            continue;
        }

        if(strcmp(c_control_str, "search") == 0)
        {
            int temp_key;
            temp_key = stoi(control_chunk[1]);
            mystore.search(temp_key);
            delete [] c_control_str;
            continue;
        }
        // main thread is sending
        reg_send(msg);
        //waiting a ACK before next send
        cout<<"I am waiting central ACK!"<<endl;
        pthread_mutex_lock (&ack_mutex);
        ack_flag = false;
        pthread_mutex_unlock (&ack_mutex);
        while(!ack_flag);
        /*
        if(send(sockfd,msg,(strlen(msg)),0)==-1)
          perror("send");//send message
        time_t now = time(0);
        char* cur_time = ctime(&now);
        cout<<"sending... ("<<msg<<" )current sys time is"<<cur_time<<endl;
        usleep(5*TICK_USEC);*/
        //numbytes1=recv(sockfd,msg,4,0);
        //cout<<"received: expecting an ACK "<<numbytes1<<endl;
        numbytes1=0;
      }
      cout<<"debug4"<<endl;
      fclose(fp);
  }
  //while(1);
  //just in case, you know
  return 0;
}
