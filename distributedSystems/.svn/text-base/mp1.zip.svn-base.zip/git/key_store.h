#ifndef KEYSTORE_H
#define KEYSTORE_H
using namespace std;
class key_store
{
public:
	int mode;
	map<int,int> store;
	map<int,int>::iterator it;

	int delete_key(int key);
	int insert_key(int key, int value);
	int update_key(int key, int value);
	int get_key(int key);
	int search(int key);
	void showall();
	void sendall();
};
#endif
