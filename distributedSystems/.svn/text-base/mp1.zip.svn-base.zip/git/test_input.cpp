#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <errno.h>
#include <string.h>
#include <netdb.h>
#include <sys/types.h>
#include <netinet/in.h>
#include <sys/socket.h>
#include <arpa/inet.h>
#define PORT "3490" // the port client will be connecting to 
#define MAXDATASIZE 100 // max number of bytes we can get at once 




//???????????????????????????????????????????????????????????????????????????
#include <pthread.h>
#include <sys/time.h>
#include <time.h>
#include "struct1.h"
#include <iostream>       // std::cin, std::cout
#include <queue>          // std::queue
using namespace std;
#include <iostream>       // std::cin, std::cout
#include <string>
using namespace std;
int main(){

  cout<<"please input an command"<<endl;
    char msg[4][20];
    int command=0;
    int insert_model=0;
    int update_model=0;
    int get_model=0;
    int i=0;
    int num_words=0;
    
char temp[20];
int j=0;
//scanf("%[^\n]",temp);
gets(temp);
cout<<"input string is: "<<temp<<endl;
for ( i = 0; i < strlen(temp); ++i)
{
  
  if (temp[i]!=' '){
            msg[j][num_words]=temp[i];
            num_words++;
  }
  else{
          j+=1;
          num_words=0;
  }
}
cout<<"total number of letters: "<<i<<endl;
cout<<"number of words: "<<j+1<<endl;
for (int k = 0; k <=j; ++k)
      {
        printf("%s\n",msg[k]);
      }
    int number_words=j+1;





//parse the read command
        char key=msg[1][0];
        cout<<"key is: "<<key<<endl;
        if (number_words==2)//if the command is "get key"
        {
          command=1;
        }
        else if(number_words==3) {//command is "get key model"
          command=2;
          switch(msg[2][0]){
          case '1': get_model=1;break;
          case '2': get_model=2;break;
          case '3': get_model=3;break;
          case '4': get_model=4;break;
          }
        }
        else if (number_words==4)//command is "insert key value model" or "update key value model"
        {

          if (msg[0][0]=='i')//command is "insert key value model"
          {
            command=3;
            switch(msg[3][0]){
            case '1': insert_model=1;break;
            case '2': insert_model=2;break;
            case '3': insert_model=3;break;
            case '4': insert_model=4;break;
             }
          }
           if (msg[0][0]=='u')//command is "update key value model"
          {
            command=4;
            switch(msg[3][0]){
            case '1': update_model=1;break;
            case '2': update_model=2;break;
            case '3': update_model=3;break;
            case '4': update_model=4;break;
            }
          }
        }
        
          cout<<"command is: "<<command<<endl;
          cout<<"get_model is: "<<get_model<<endl;
          cout<<"insert_model is: "<<insert_model<<endl;
          cout<<"update_model is: "<<update_model<<endl;
       
return 0;
}

