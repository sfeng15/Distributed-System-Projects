#!/bin/bash
make
reset
./c_server
