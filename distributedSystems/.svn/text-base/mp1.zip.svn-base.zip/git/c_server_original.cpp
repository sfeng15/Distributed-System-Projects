/*
** server.c -- a stream socket server
*/
#include <iostream>
#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <errno.h>
#include <string.h>
#include <sys/types.h>
#include <sys/socket.h>
#include <netinet/in.h>
#include <netdb.h>
#include <arpa/inet.h>
#include <sys/wait.h>
#include <signal.h>
#include <pthread.h>


using namespace std;

#define NUM_THREADS     5

#define PORT "3490"  // the port users will be connecting to

#define BACKLOG 10	 // how many pending connections queue will hold

#define MAXDATASIZE 100 // max number of bytes we can get at once 

void *send_cb(void* msg);
void *listen_cb( void* msg);

typedef struct server_info
{
	char name[2];	//name must be less than 20 characters
	int fd;
} server_info_t;

server_info_t node[NUM_THREADS]; 	//4 connection threads one stand alone send thread	 

typedef struct send_info
{
public:
	server_info_t from;
	server_info_t to;
	char mesg[MAXDATASIZE];
	//send_info(){
	//	memset(mesg,'\0',sizeof(mesg));
	//}
}send_info_t; 

void sigchld_handler(int s)
{
	while(waitpid(-1, NULL, WNOHANG) > 0);
}

// get sockaddr, IPv4 or IPv6:
void *get_in_addr(struct sockaddr *sa)
{
	if (sa->sa_family == AF_INET) {
		return &(((struct sockaddr_in*)sa)->sin_addr);
	}

	return &(((struct sockaddr_in6*)sa)->sin6_addr);
}


// client thread entry point in central server
void *listen_cb( void* msg){
		//server_info_t *arg = (server_info_t *) msg;
		//char buf[MAXDATASIZE]="";
		//recv(arg->fd,buf,MAXDATASIZE-1,0);
		//cout<<buf<<endl;
	pthread_t send_thd;
	//local temp storage
	char temp_msg[MAXDATASIZE]="";
	char src_name[2];
	char dest_name[2];
	char dummy[20]="";
	//for connection storage
	char buf[MAXDATASIZE]="";
	size_t numbytes;
	server_info_t *arg = (server_info_t *) msg;
	send_info_t tbs;
	//testing
	printf("I am %s\n", arg->name);
	printf("my fd is %d\n", arg->fd);
	while(1){
		numbytes=recv(arg->fd, buf, MAXDATASIZE-1, 0);
		//printf("numbytes: %d\n",numbytes);
		if(!numbytes) continue;	//no connection yet, keep looping
		//send(arg->fd,"ACK",3,0);
		cout<<numbytes<<endl;
		buf[numbytes]='\0';
		printf("received: %s\n",buf );
		//parsing
		strcpy(tbs.mesg,buf);
		cout<<"mesg is: "<<tbs.mesg<<endl;
		cout<<"success on scan: "<<sscanf(buf,"%s send %s %s", src_name, temp_msg, dest_name)<<endl;//A send Hello B
		printf("src_name: %s\n", src_name);
		printf("dest_name: %s\n", dest_name);
		printf("temp_msg: %s\n", temp_msg);
			switch (dest_name[0]){
			case 'A':
				tbs.to=node[0];
				cout<<"here: "<<tbs.to.name<<' '<<tbs.to.fd<<endl;
				break;
			case 'B':
				tbs.to=node[1]; break;
			case 'C':
				tbs.to=node[2]; break;
			case 'D':
				tbs.to=node[3]; break;
			}

			switch (src_name[0]){
			case 'A':
				tbs.from=node[0]; break;
			case 'B':
				tbs.from=node[1]; break;
			case 'C':
				tbs.from=node[2]; break;
			case 'D':
				tbs.from=node[3]; break;
			}
		pthread_create( &send_thd, NULL, send_cb, (void*) &tbs);
		}	
}

//stand alone sending thread that exits upon success
void *send_cb(void* msg){
	printf("sending in send_cb... \n");
	send_info_t *arg =(send_info_t *) msg;
	//printf("before here!\n");
	//cout<<arg<<endl;
	cout<<arg->mesg<<endl;
	printf("%s\n%d \n", arg->to.name,arg->to.fd);
	if(send(arg->to.fd,arg->mesg,strlen(arg->mesg),0) == -1) 
		perror("send");	
	//exit(0);
}

int main()
{	
	int sockfd;  // listen on sock_fd, new connection on new_fd
	struct addrinfo hints, *servinfo, *p;
	struct sockaddr_storage their_addr; // connector's address information
	socklen_t sin_size;
	struct sigaction sa;
	int yes=1;
	char s[INET6_ADDRSTRLEN];
	int rv;

	 pthread_t threads[NUM_THREADS];	//5 threads for listening
	 pthread_t send_thd;
	 int count=0;	//counting number of connection 

	//establish connection
	memset(&hints, 0, sizeof hints);
	hints.ai_family = AF_UNSPEC;
	hints.ai_socktype = SOCK_STREAM;
	hints.ai_flags = AI_PASSIVE; // use my IP

	if ((rv = getaddrinfo(NULL, PORT, &hints, &servinfo)) != 0) {
		fprintf(stderr, "getaddrinfo: %s\n", gai_strerror(rv));
		return 1;
	}

	// loop through all the results and bind to the first we can
	for(p = servinfo; p != NULL; p = p->ai_next) {
		if ((sockfd = socket(p->ai_family, p->ai_socktype,
				p->ai_protocol)) == -1) {
			perror("server: socket");
			continue;
		}

		if (setsockopt(sockfd, SOL_SOCKET, SO_REUSEADDR, &yes,
				sizeof(int)) == -1) {
			perror("setsockopt");
			exit(1);
		}

		if (bind(sockfd, p->ai_addr, p->ai_addrlen) == -1) {
			close(sockfd);
			perror("server: bind");
			continue;
		}

		break;
	}

	if (p == NULL)  {
		fprintf(stderr, "server: failed to bind\n");
		return 2;
	}

	freeaddrinfo(servinfo); // all done with this structure

	if (listen(sockfd, BACKLOG) == -1) {
		perror("listen");
		exit(1);
	}

	sa.sa_handler = sigchld_handler; // reap all dead processes
	sigemptyset(&sa.sa_mask);
	sa.sa_flags = SA_RESTART;
	if (sigaction(SIGCHLD, &sa, NULL) == -1) {
		perror("sigaction");
		exit(1);
	}

	printf("server: waiting for connections...\n");
    //pthread_create( &send_thd, NULL, send_cb, (void*) NULL);

	while(1) {  // main accept() loop
		sin_size = sizeof their_addr;
		node[count].fd= accept(sockfd, (struct sockaddr *)&their_addr, &sin_size);
		if (node[count].fd == -1) {
			perror("accept");
			continue;
		}

		inet_ntop(their_addr.ss_family,
			get_in_addr((struct sockaddr *)&their_addr),
			s, sizeof s);
		printf("server: got connection from %s\n", s);
		//assign server names
		switch(count){
			case 0:
				node[count].name[0] ='A';
				break;
			case 1:
				node[count].name[0] ='B';
				break;
			case 2:
				node[count].name[0] ='C';
				break;
			case 3:
				node[count].name[0] ='D';
				break;
			default:
				printf("too many connection! abort...\n");
				return 0;
		}
		//char buf[MAXDATASIZE]="";
		//recv(node[count].fd,buf,MAXDATASIZE-1,0);
		//cout<<buf<<endl;
     	pthread_create( &threads[count], NULL, listen_cb, (void*) &node[count]);
     	count++;	
		//if ((numbytes = recv(new_fd, buf, MAXDATASIZE-1, 0)) == -1) 	
	}
	return 0;
}
