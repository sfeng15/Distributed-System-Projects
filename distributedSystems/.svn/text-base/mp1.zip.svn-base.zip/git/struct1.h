#ifndef QUEUE_H
#define QUEUE_H
class Message{

		public :
		char buf[20];
		int counter;
		int fd;
		pthread_t *myID; 
		Message(){memset(buf,'\0', sizeof buf);}
		int target_number;
		int target1;
		int target2;

};
#endif
