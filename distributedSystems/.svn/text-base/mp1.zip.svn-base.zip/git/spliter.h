#ifndef SPLITER_H
#define SPLITER_H
#include <string>
#include <vector>
#include <iostream>
using namespace std;

class splitstring : public string {
    vector<string> flds;
public:
    splitstring(char *s) : string(s) { };
    vector<string>& split(char delim, int rep=0);
};

#endif

