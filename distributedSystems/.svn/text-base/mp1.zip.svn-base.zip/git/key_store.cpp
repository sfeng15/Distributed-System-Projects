#include <cstdlib>
#include <iostream>
#include <netinet/in.h>
#include <netdb.h>
#include <sys/wait.h>
#include <signal.h>
#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <errno.h>
#include <string.h>
#include <string>
#include <cstring>
#include <netdb.h>
#include <sys/types.h>
#include <netinet/in.h>
#include <sys/socket.h>
#include <arpa/inet.h>
#include <pthread.h>
#include <sys/time.h>
#include <time.h>
#include <ctime>
#include "struct1.h"
#include <iostream>       // std::cin, std::cout
#include <queue>          // std::queue
#include <map>            //std::map c++11
#include "spliter.h"
#include "key_store.h"

using namespace std;


int key_store::delete_key(int key){
	it=store.find(key);
	if(it!=store.end()){
		store.erase(it);
		return 0;
	}
	else return -1;		 
}	
int key_store::insert_key(int key,int value){
	it=store.find(key);
	if(it!=store.end()){
		it->second = value;
	}
	else{
		store[key] = value;
	}
	return 0;
}
int key_store::update_key(int key, int value){
	it=store.find(key);
	if(it!=store.end()){
		it->second = value;
	}
	else{
		return -1;
	}
	return 0;
}
int key_store::get_key(int key){
	it=store.find(key);
	if(it==store.end()) return -1;
	else return store[key];
}

int key_store::search(int key){
	cout<<"find key: "<<key<<", value is: "<<store.find(key)->second<<endl;
	return 0;
	}
void key_store::showall(){
	cout<<"displaying items in stock..."<<endl;
  	for (map<int,int>::iterator foo = store.begin(); foo!=store.end(); ++foo){
		cout<<"key is: "<<foo->first<<" value is: "<<foo->second<<endl;
	}
}
