/*
** server.c -- a stream socket server
*/
/*
#include <iostream>
#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <errno.h>
#include <string.h>
#include <sys/types.h>
#include <sys/socket.h>
#include <netinet/in.h>
#include <netdb.h>
#include <arpa/inet.h>
#include <sys/wait.h>
#include <signal.h>
#include <pthread.h>
#include "struct1.h"
#include "key_store.h"
#include <map>            //std::map c++11
#include "spliter.h"
#include <queue>          // std::queue
*/







#include <iostream>
#include <netinet/in.h>
#include <netdb.h>
#include <sys/wait.h>
#include <signal.h>
#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <errno.h>
#include <string.h>
#include <string>
#include <cstring>
#include <netdb.h>
#include <sys/types.h>
#include <netinet/in.h>
#include <sys/socket.h>
#include <arpa/inet.h>
#include <pthread.h>
#include <sys/time.h>
#include <time.h>
#include <ctime>
#include "struct1.h"
#include <iostream>       // std::cin, std::cout
#include <queue>          // std::queue
#include <map>            //std::map c++11
#include "spliter.h"
#include "key_store.h"

using namespace std;

#define NUM_THREADS     5

#define PORT "3490"  // the port users will be connecting to

#define BACKLOG 10	 // how many pending connections queue will hold

#define MAXDATASIZE 100 // max number of bytes we can get at once 


void sigchld_handler(int s)
{
	while(waitpid(-1, NULL, WNOHANG) > 0);
}
// get sockaddr, IPv4 or IPv6:
void *get_in_addr(struct sockaddr *sa)
{
	if (sa->sa_family == AF_INET) {
		return &(((struct sockaddr_in*)sa)->sin_addr);
	}

	return &(((struct sockaddr_in6*)sa)->sin6_addr);
}


void *send_cb(void* msg);
void *listen_cb( void* msg);

typedef struct server_info
{
	char name[2];	//name must be less than 20 characters
	int fd;
} server_info_t;

server_info_t node[NUM_THREADS]; 	//4 connection threads one stand alone send thread	 

typedef struct send_info
{
	public:
		server_info_t from;
		server_info_t to;
		char mesg[MAXDATASIZE];
}send_info_t; 




//newly added global variables
queue<Message> myqueue;
queue<int> countqueue;  //store temp counter value
int target_number=0;
int target1;
int target2;
int delete_flag=0;
//int eventual_mode;
pthread_t delay_t[100];
int ack_counter=0;;//count the number of ack
pthread_mutex_t delete_mutex = PTHREAD_MUTEX_INITIALIZER;
 pthread_t threads[NUM_THREADS];	//5 threads for listening
key_store key;//instantiate the key
// client thread entry point in central server
//
//
//
void *listen_cb( void* msg){
		

	Message message_struct;//store the info
	int counter=0;//queue counter


	int key_number;
    int value;
    int model;
    int timestamp;
	char buf[MAXDATASIZE]="";
	size_t numbytes;

	server_info_t *arg = (server_info_t *) msg;
	


	//testing
	//printf("I am %s\n", arg->name);
	//printf("my fd is %d\n", arg->fd);


	while(1){
		numbytes=recv(arg->fd, buf, MAXDATASIZE-1, 0);
		if(!numbytes) continue;	//no connection yet, keep looping
		
		//debug statement
		cout<<"number of bytes is: "<<numbytes<<endl;
		buf[numbytes]='\0';
		cout<<"received message is: "<<buf<<endl;

		//parsing the received message
		//and store the lastest value in the global dictionary
		//
		splitstring recv_msg(buf);
        vector<string> chunk = recv_msg.split(' ');
        string control = chunk[0];
        char *c_control = new char[control.length()+1];
        strcpy(c_control, control.c_str());


		 if (strcmp(c_control,"delete")==0){
		 	pthread_mutex_lock (&delete_mutex);
		 		if (ack_counter==4)
		 		{
		 			ack_counter=0;
		 			delete_flag=1;
		 		}
				
				pthread_mutex_unlock (&delete_mutex);
			//myqueue.pop();
		 }
      	// linireazibility and sequencial and eventual send write ack routine
      	//
      	//
        if (strcmp(buf,"ACK")==0)
        {	ack_counter+=1;


        	splitstring temp_recv_msg(myqueue.front().buf);
        	vector<string> chunk1 = temp_recv_msg.split(' ');

        	if(chunk1.size() == 3)//get the model 
	        	model = stoi(chunk1[2],NULL,0);
	        if(chunk1.size() == 4)
	        	model = stoi(chunk1[3],NULL,0);

//cout<<"front buf is: "<<myqueue.front().buf<<endl;
//cout<<"chunck is: "<<chunk1[3]<<endl;
//cout<<"model is: "<<model<<endl;
//cout<<"ack_counter is: "<<ack_counter<<endl;

        	if (model==1||model==2)//liniearizability\sequencial write  mode
        	{
        		if (ack_counter==4)//wait for 4 ack and then send ack to the source
					{
						ack_counter=0;
						int sockfd=myqueue.front().fd;
						if(send(sockfd,"ACK",strlen("ACK"),0)==-1)
			          		perror("send");//send message
			          	myqueue.pop();
			    
		        	}
        	}
        	if (model==3)//	eventual 1 write mode
        	{
        		if (ack_counter==1)//wait for 1 ack and then send ack to the source
					{
						ack_counter=0;
						int sockfd=myqueue.front().fd;
						cout<<"sockfd is: "<<sockfd<<endl;
						if(send(sockfd,"ACK",strlen("ACK"),0)==-1)
			          		perror("send");//send message
			          	myqueue.pop();
			    
		        	}
        	}
        	if (model==4)//	eventual 2 write mode
        	{
        		if (ack_counter==2)//wait for 2 ack and then send ack to the source
					{
						ack_counter=0;
						int sockfd=myqueue.front().fd;
						if(send(sockfd,"ACK",strlen("ACK"),0)==-1)
			          		perror("send");//send message
			          	myqueue.pop();
			    
		        	}
        	}
        	        	

        }

        //linearazibility/sequencial/eventual send read ack routine
        //
        //
        char buf1[MAXDATASIZE]="";
        char buf2[MAXDATASIZE]="";
        int timestamp1=0;
        int timestamp2=0;
        cout<<"chunk size is: "<<chunk.size()<<endl;
        cout<<"c_control is: "<<c_control<<endl;

		if (strcmp(c_control,"ACK")==0&&chunk.size()!=1)//ack(y) key(y) value(y) timestamp(n)  model 
		{				
														//0  	1   	 2     		3      		4 	
			key_number = stoi(chunk[1],NULL,0);//check condition
			value = stoi(chunk[2],NULL,0);
			timestamp=stoi(chunk[3],NULL,0);
			model = stoi(chunk[4],NULL,0);


			ack_counter+=1;
			cout<<"special number of counter: "<<ack_counter<<endl;

			//buffer[ack_counter]="ACK"+chunk[1]+chunk[2];
			if (ack_counter==1)
			{
				strcpy(buf1,buf);
				timestamp1=timestamp;
				
			}
			if (ack_counter==2)
			{
				strcpy(buf2,buf);
				timestamp2=timestamp;
			
			}
			if (ack_counter==4)
			{
				//strcpy(buf2,buf);
				//timestamp2=timestamp;
				ack_counter=0;
				int sockfd=myqueue.front().fd;
				if(send(sockfd,"ACK",strlen("ACK"),0)==-1)
	          		perror("send");//send message
				myqueue.pop();
			}

			if (model==3)
			{
				if (ack_counter==1)
				{
					//pthread_mutex_lock (&ack_mutex);
					ack_counter=0;
					//pthread_mutex_unlock (&ack_mutex);
					int sockfd=myqueue.front().fd;
					if(send(sockfd,buf,(strlen(buf)),0)==-1)
		          		perror("send");//send message
		          	myqueue.pop();
	        	}
			}
			if (model==4)
			{
				if (ack_counter==2)
				{

					int sockfd=myqueue.front().fd;
					//pthread_mutex_lock (&ack_mutex);
					ack_counter=0;
					//pthread_mutex_unlock (&ack_mutex);
					if (timestamp1>timestamp2){
						if(send(sockfd,buf2,(strlen(buf2)),0)==-1)
		          		perror("send");//send message
					}
					else{
						if(send(sockfd,buf1,(strlen(buf1)),0)==-1)
		          		perror("send");//send message
					}
				   	myqueue.pop();

				}
			}
				
			
		}

		//if the message is normal message,handle the enqueue function
		//
		//
		else if(strcmp(c_control,"ACK"))
		{
			 key_number = stoi(chunk[1],NULL,0);//check condition
			if(strcmp(c_control,"delete")==0)
				key.delete_key(key_number);

			if(chunk.size() == 3)//get set the target if the eventual consistency
	        {
	        	model = stoi(chunk[2],NULL,0);
	        	switch(model)
				{
					case 3: target_number=1;break;
					case 4: target_number=2;break;
					default: target_number=4;break;
				}
	        }
	        else if(chunk.size() == 4)	//update/insert
	        {
	          	value = stoi(chunk[2],NULL,0);
	          	if(strcmp(c_control,"insert")==0)
					key.insert_key(key_number,value);
				if(strcmp(c_control,"update")==0)
					key.update_key(key_number,value);
	            model = stoi(chunk[3],NULL,0); 
	            switch(model)
				{
					case 3: target_number=1;break;
					case 4: target_number=2;break;
					default: target_number=4;break;
				}

	        }else target_number=4;	//delete
	        //randomly pick 2 numbers or randomly pick one
			//		
	        //
	        message_struct.target_number=target_number;
			if (message_struct.target_number==2)//pick two
			{
				srand(time(NULL));
				message_struct.target1=rand()%4; //target is between 1 and 4
				message_struct.target2=0;
		   		while( message_struct.target1==message_struct.target2 ) //wait until the message are different
		    	 message_struct.target2=rand()%4;
			}
			if (message_struct.target_number==1)//pick one
			{
				srand(time(NULL));
				message_struct.target1=rand()%4; //target is between 1 and 4
			}

			strcpy(message_struct.buf,buf);//copy all the data from buf into
	   		message_struct.counter=counter;
	   		counter++;
	   		message_struct.fd=arg->fd;//senders' fd
	   		message_struct.myID = &delay_t[message_struct.counter];        
	        myqueue.push (message_struct);
	        memset(message_struct.buf,'\0',sizeof message_struct.buf);
			
			pthread_create(&(delay_t[message_struct.counter]), NULL, send_cb, NULL);
		}	delete [] c_control;
	} 
}

//stand alone sending thread that exits upon success
void *send_cb(void* msg){

	 cout<<"I wake up!"<<" my number is: "<<pthread_self()<<endl;
	 Message curr_message;

 while (!myqueue.empty())
      {
      
	    while(*(myqueue.front().myID)!=pthread_self());
	    
	   	curr_message=myqueue.front();
	    if (curr_message.target_number==1)
	    {
	    	if(send(node[curr_message.target1].fd,curr_message.buf,strlen(curr_message.buf),0) == -1) 
			perror("1 command send to target1 fail");	
			
	    }
	    else if (curr_message.target_number==2)
	    {
	    	if(send(node[curr_message.target1].fd,curr_message.buf,strlen(curr_message.buf),0) == -1) 
			perror("2 commands send to target1 fail");	
			if(send(node[curr_message.target2].fd,curr_message.buf,strlen(curr_message.buf),0) == -1) 
			perror("2 commands send to target2 fail");

	    }
	    else{
			if(send(node[0].fd,curr_message.buf,strlen(curr_message.buf),0) == -1) 
				perror("send to a");	
			if(send(node[1].fd,curr_message.buf,strlen(curr_message.buf),0) == -1) 
				perror("send to b");	
			if(send(node[2].fd,curr_message.buf,strlen(curr_message.buf),0) == -1) 
				perror("send to c");	
			if(send(node[3].fd,curr_message.buf,strlen(curr_message.buf),0) == -1) 
				perror("send to d");


		}
			if(delete_flag){
				myqueue.pop();
				pthread_mutex_lock (&delete_mutex);
				delete_flag=0;
				pthread_mutex_unlock (&delete_mutex);

			}

        break;
	}	
}


void * time_thread_fun(void *){

while(1){

	sleep(80);
	cout<<"repair start"<<endl;
	int time_thread_counter=0;
	int time_numbytes=0;
	char time_buf[100]="";
	//key.sendall();
	//map<int,int> store;

  	for (map<int,int>::iterator foo = key.store.begin(); foo!=key.store.end(); ++foo){
		cout<<"key is: "<<foo->first<<" value is: "<<foo->second<<endl;

	string foo_first_str = to_string(static_cast<long long>(foo->first));
	string foo_second_str = to_string(static_cast<long long>(foo->second));
		string msg = "insert "+ foo_first_str +' '+ foo_second_str+' '+"1";//+ model 1
		char *mymsg = new char [msg.length()+1];
    	strcpy(mymsg, msg.c_str());


 pthread_cancel(threads[0]);//stop the listening thread
  pthread_cancel(threads[1]);
   pthread_cancel(threads[2]);
    pthread_cancel(threads[3]);

		if(send(node[0].fd,mymsg,strlen(mymsg),0) == -1) 
			perror("send to a");	
			while(1){
				time_numbytes=recv(node[time_thread_counter].fd,time_buf, MAXDATASIZE-1, 0);
				cout<<"number of bytes is: "<<time_numbytes<<endl;
				cout<<"received message is: "<<time_buf<<endl;
				if (strcmp(time_buf,"ACK")==0)
				{	time_thread_counter++;
					break;
				}
			}
		if(send(node[1].fd,mymsg,strlen(mymsg),0) == -1) 
			perror("send to b");	
			while(1){
					time_numbytes=recv(node[time_thread_counter].fd,time_buf, MAXDATASIZE-1, 0);
					cout<<"number of bytes is: "<<time_numbytes<<endl;
					cout<<"received message is: "<<time_buf<<endl;
					if (strcmp(time_buf,"ACK")==0)
					{	time_thread_counter++;
						break;
					}
				}
		if(send(node[2].fd,mymsg,strlen(mymsg),0) == -1) 
			perror("send to c");	
			while(1){
				time_numbytes=recv(node[time_thread_counter].fd,time_buf, MAXDATASIZE-1, 0);
				cout<<"number of bytes is: "<<time_numbytes<<endl;
				cout<<"received message is: "<<time_buf<<endl;
				if (strcmp(time_buf,"ACK")==0)
				{	time_thread_counter++;
					break;
				}
			}
		if(send(node[3].fd,mymsg,strlen(mymsg),0) == -1) 
			perror("send to d");
			while(1){
				time_numbytes=recv(node[time_thread_counter].fd,time_buf, MAXDATASIZE-1, 0);
				cout<<"number of bytes is: "<<time_numbytes<<endl;
				cout<<"received message is: "<<time_buf<<endl;
				if (strcmp(time_buf,"ACK")==0)
				{	time_thread_counter=0;
					break;
				}
			}

	
		}

	pthread_create( &threads[0], NULL, listen_cb, (void*) &node[0]);
	pthread_create( &threads[1], NULL, listen_cb, (void*) &node[1]);
	pthread_create( &threads[2], NULL, listen_cb, (void*) &node[2]);
	pthread_create( &threads[3], NULL, listen_cb, (void*) &node[3]);
	}

}



int main()
{	
	int sockfd;  // listen on sock_fd, new connection on new_fd
	struct addrinfo hints, *servinfo, *p;
	struct sockaddr_storage their_addr; // connector's address information
	socklen_t sin_size;
	struct sigaction sa;
	int yes=1;
	char s[INET6_ADDRSTRLEN];
	int rv;

	
	 pthread_t send_thd;
	 int count=0;	//counting number of connection 

	//establish connection
	memset(&hints, 0, sizeof hints);
	hints.ai_family = AF_UNSPEC;
	hints.ai_socktype = SOCK_STREAM;
	hints.ai_flags = AI_PASSIVE; // use my IP

	if ((rv = getaddrinfo(NULL, PORT, &hints, &servinfo)) != 0) {
		fprintf(stderr, "getaddrinfo: %s\n", gai_strerror(rv));
		return 1;
	}

	// loop through all the results and bind to the first we can
	for(p = servinfo; p != NULL; p = p->ai_next) {
		if ((sockfd = socket(p->ai_family, p->ai_socktype,
				p->ai_protocol)) == -1) {
			perror("server: socket");
			continue;
		}

		if (setsockopt(sockfd, SOL_SOCKET, SO_REUSEADDR, &yes,
				sizeof(int)) == -1) {
			perror("setsockopt");
			exit(1);
		}

		if (bind(sockfd, p->ai_addr, p->ai_addrlen) == -1) {
			close(sockfd);
			perror("server: bind");
			continue;
		}

		break;
	}

	if (p == NULL)  {
		fprintf(stderr, "server: failed to bind\n");
		return 2;
	}

	freeaddrinfo(servinfo); // all done with this structure

	if (listen(sockfd, BACKLOG) == -1) {
		perror("listen");
		exit(1);
	}

	sa.sa_handler = sigchld_handler; // reap all dead processes
	sigemptyset(&sa.sa_mask);
	sa.sa_flags = SA_RESTART;
	if (sigaction(SIGCHLD, &sa, NULL) == -1) {
		perror("sigaction");
		exit(1);
	}




	//create a new thread for repairing
	//
	//
	//
	pthread_t time_thread_t;
	pthread_create( &time_thread_t, NULL, time_thread_fun, NULL);



	printf("server: waiting for connections...\n");
    //pthread_create( &send_thd, NULL, send_cb, (void*) NULL);

	while(1) {  // main accept() loop
		sin_size = sizeof their_addr;
		node[count].fd= accept(sockfd, (struct sockaddr *)&their_addr, &sin_size);
		if (node[count].fd == -1) {
			perror("accept");
			continue;
		}

		inet_ntop(their_addr.ss_family,
			get_in_addr((struct sockaddr *)&their_addr),
			s, sizeof s);
		printf("server: got connection from %s\n", s);
		//assign server names
		switch(count){
			case 0:
				node[count].name[0] ='A';
				break;
			case 1:
				node[count].name[0] ='B';
				break;
			case 2:
				node[count].name[0] ='C';
				break;
			case 3:
				node[count].name[0] ='D';
				break;
			default:
				printf("too many connection! abort...\n");
				return 0;
		}
		//char buf[MAXDATASIZE]="";
		//recv(node[count].fd,buf,MAXDATASIZE-1,0);
		//cout<<buf<<endl;
		//if (!fork()) { // this is the child process
     	pthread_create( &threads[count], NULL, listen_cb, (void*) &node[count]);
     	count++;	
		//if ((numbytes = recv(new_fd, buf, MAXDATASIZE-1, 0)) == -1) 	
	}
	return 0;
}
