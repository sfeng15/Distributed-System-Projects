#ifndef QUEUE_H
#define QUEUE_H
#include <unistd.h>
class Message{
public:
		char buf[15];
		int counter;
		pthread_t *myID; 
		Message(){memset(buf,'\0', sizeof buf);}
};
#endif
