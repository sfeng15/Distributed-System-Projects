#!/bin/bash
reset
./r_server 127.0.0.1
