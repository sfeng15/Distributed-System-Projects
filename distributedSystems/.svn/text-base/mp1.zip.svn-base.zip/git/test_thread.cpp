#include <iostream>
#include <pthread.h>
#include <stdio.h>

using namespace std;
//int x=1;
//int y=2;
int flag=1;

void *inc_x(void *x_void_ptr)
{

    int *x_ptr = (int *)x_void_ptr;
cout<<"thread"<<endl;
    printf("%d \n",*x_ptr);
    //while(1);
    pthread_exit(NULL);

}
/*
void *inc_y(void *x_void_ptr)
{

    int *x_ptr = (int *)x_void_ptr;
cout<<"x y is"<<endl;
    printf("%d",*x_ptr);
    
    return NULL;

}
*/
int main()
{

    int x = 0, y = 1;
    printf("x: %d, y: %d\n", x, y);
  
    pthread_t inc_x_thread1;
    pthread_t inc_x_thread2;
   pthread_create(&inc_x_thread1, NULL, inc_x, &y);
	cout<<"before thread exit"<<endl;
/*
if(pthread_join(inc_x_thread1, NULL)) {

fprintf(stderr, "Error joining thread\n");
return 2;

}
*/
cout<<"main"<<endl;
	//if(flag==1) goto end;
	//else
    //pthread_create(&inc_x_thread2, NULL, inc_x, &y);
	//while(1);
//end:;
}
